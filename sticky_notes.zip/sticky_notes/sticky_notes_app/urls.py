from django.urls import path
from .views import home, get_all_tasks, get_task, create, update, delete

app_name = 'sticky_notes_app'

urlpatterns = [
    path('', home, name='home'),  # Home page
    path('tasks/', get_all_tasks, name='tasks'),  # List all tasks
    path('task/<int:pk>/', get_task, name='task-detail'),  # Task detail view
    path('create/', create, name='create_task'),  # Create task
    path('update/<int:pk>/', update, name='update_task'),  # Update task
    path('delete/<int:pk>/', delete, name='delete_task'),  # Delete task
]
