from django.test import TestCase
from django.urls import reverse
from .models import User, Create_Task
from datetime import date

class UserModelTest(TestCase):

    def setUp(self):
        self.user = User.objects.create(
            email_address='testuser@example.com',
            password='password123'
        )

    def test_user_creation(self):
        self.assertEqual(self.user.email_address, 'testuser@example.com')
        self.assertEqual(self.user.password, 'password123')
        self.assertEqual(str(self.user), 'testuser@example.com')


class TaskModelTest(TestCase):

    def setUp(self):
        self.task = Create_Task.objects.create(
            title='Test Task',
            description='This is a test task.',
            due_date=date.today(),
            complete=False
        )

    def test_task_creation(self):
        self.assertEqual(self.task.title, 'Test Task')
        self.assertEqual(self.task.description, 'This is a test task.')
        self.assertEqual(self.task.due_date, date.today())
        self.assertFalse(self.task.complete)
        self.assertEqual(str(self.task), 'Test Task')


class TaskViewsTest(TestCase):

    def setUp(self):
        self.task = Create_Task.objects.create(
            title='Test Task',
            description='This is a test task.',
            due_date=date.today(),
            complete=False
        )

    def test_get_all_tasks(self):
        response = self.client.get(reverse('sticky_notes_app:tasks'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Task')
        self.assertTemplateUsed(response, 'tasks/index.html')

    def test_get_task(self):
        response = self.client.get(reverse('sticky_notes_app:task', args=[self.task.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Task')
        self.assertTemplateUsed(response, 'tasks/task.html')

    def test_create_task(self):
        response = self.client.post(reverse('sticky_notes_app:create'), {
            'title': 'New Task',
            'description': 'New task description',
            'due_date': '2024-12-31',
            'complete': False,
        })
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse('sticky_notes_app:tasks'))
        self.assertEqual(Create_Task.objects.count(), 2)

    def test_update_task(self):
        response = self.client.post(reverse('sticky_notes_app:update', args=[self.task.pk]), {
            'title': 'Updated Task',
            'description': 'Updated task description',
            'due_date': '2024-12-31',
            'complete': True,
        })
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse('sticky_notes_app:tasks'))
        self.task.refresh_from_db()
        self.assertEqual(self.task.title, 'Updated Task')
        self.assertTrue(self.task.complete)

    def test_delete_task(self):
        response = self.client.post(reverse('sticky_notes_app:delete', args=[self.task.pk]))
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse('sticky_notes_app:home'))
        self.assertEqual(Create_Task.objects.count(), 0)

    def test_home_page(self):
        response = self.client.get(reverse('sticky_notes_app:home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Task')
        self.assertTemplateUsed(response, 'home.html')
