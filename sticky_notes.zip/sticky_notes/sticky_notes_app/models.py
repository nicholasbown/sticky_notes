from django.db import models

class User(models.Model):
    """User model."""
    email_address = models.EmailField(max_length=30)
    password = models.CharField(max_length=30)

    def __str__(self):
        return self.email_address  

class Create_Task(models.Model):
    """Task model."""
    title = models.CharField(max_length=255)
    description = models.TextField()
    due_date = models.DateField()
    complete = models.BooleanField(default=False)

    def __str__(self):
        return self.title 
