from django.shortcuts import render, redirect, get_object_or_404
from .models import Create_Task  # Corrected import for models
from .Forms import TaskForm  # Corrected import for forms

def get_all_tasks(request):
    """List all tasks."""
    tasks = Create_Task.objects.all()
    context = {
        'tasks': tasks,
        'page_title': 'Tasks'
    }
    return render(request, 'tasks/index.html', context)

def get_task(request, pk):
    """Retrieve a single task."""
    task = get_object_or_404(Create_Task, pk=pk)
    return render(request, 'tasks/task.html', {'task': task})

def create(request):
    """Create a new task."""
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('sticky_notes_app:tasks')
    else:
        form = TaskForm()
    return render(request, 'tasks/task_form.html', {'form': form})

def update(request, pk):
    """Update an existing task."""
    task = get_object_or_404(Create_Task, pk=pk)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('sticky_notes_app:tasks')
    else:
        form = TaskForm(instance=task)
    return render(request, 'tasks/task_form.html', {'form': form})

def delete(request, pk):
    """Delete a task."""
    task = get_object_or_404(Create_Task, pk=pk)
    task.delete()
    return redirect('sticky_notes_app:home')

def home(request):
    """Display the home page."""
    tasks = Create_Task.objects.all()
    context = {
        'tasks': tasks,
    }
    return render(request, 'home.html', context)
