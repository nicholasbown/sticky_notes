from django.contrib import admin
from .models import User, Create_Task

# Register your models here.
admin.site.register(User)  # Register User model
admin.site.register(Create_Task)  # Register Create_Task model
