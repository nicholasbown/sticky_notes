from django.apps import AppConfig

class StickyNotesAppConfig(AppConfig):
    """Configuration for the Sticky Notes app."""
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sticky_notes_app'
