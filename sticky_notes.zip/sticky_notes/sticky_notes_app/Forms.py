from django import forms
from .models import Create_Task

class TaskForm(forms.ModelForm):
    class Meta:
        model = Create_Task
        fields = [ 'title', 'description', 'due_date', 'complete']  # Corrected fields list
